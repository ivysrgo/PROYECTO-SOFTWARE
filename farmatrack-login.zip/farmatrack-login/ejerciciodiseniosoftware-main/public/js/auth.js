/**
 * public/js/auth.js
 * Interacciones del formulario de login.
 */

// Rellena el formulario con las credenciales del usuario demo
function fillLogin(email, password) {
  const emailInput    = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  if (emailInput)    emailInput.value    = email;
  if (passwordInput) passwordInput.value = password;
  // Efecto visual
  if (emailInput) {
    emailInput.style.transition = 'background .2s';
    emailInput.style.background = '#e6f7f0';
    setTimeout(() => { emailInput.style.background = ''; }, 600);
  }
}

document.addEventListener('DOMContentLoaded', () => {

  // Toggle mostrar/ocultar contraseña
  const toggleBtn = document.getElementById('togglePwd');
  const pwdInput  = document.getElementById('password');
  if (toggleBtn && pwdInput) {
    toggleBtn.addEventListener('click', () => {
      const isPassword = pwdInput.type === 'password';
      pwdInput.type        = isPassword ? 'text' : 'password';
      toggleBtn.textContent = isPassword ? '🙈' : '👁️';
    });
  }

  // Deshabilitar botón mientras envía para evitar doble submit
  const form      = document.getElementById('loginForm');
  const submitBtn = document.getElementById('submitBtn');
  if (form && submitBtn) {
    form.addEventListener('submit', () => {
      submitBtn.disabled    = true;
      submitBtn.textContent = 'Ingresando...';
    });
  }

});
