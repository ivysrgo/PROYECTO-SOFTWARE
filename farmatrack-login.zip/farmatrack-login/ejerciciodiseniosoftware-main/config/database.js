/**
 * config/database.js
 * Base de datos en memoria para FarmaTrack.
 * Contiene los usuarios del sistema con contraseñas en texto plano (demo).
 * En producción: usar bcrypt + PostgreSQL/MySQL.
 */
'use strict';

const db = {
  usuarios: [
    {
      id:       'u-001',
      nombre:   'Juan Bahos',
      email:    'juan.bahos@farmatrack.co',
      password: '1234',           // demo — en prod sería hash bcrypt
      rol:      'director_tecnico',
      cargo:    'Director Técnico',
      activo:   true,
    },
    {
      id:       'u-002',
      nombre:   'Sergio Velandia',
      email:    'sergio.velandia@farmatrack.co',
      password: '1234',
      rol:      'operario',
      cargo:    'Operario de Producción',
      activo:   true,
    },
    {
      id:       'u-003',
      nombre:   'David Peña',
      email:    'david.pena@farmatrack.co',
      password: '1234',
      rol:      'calidad',
      cargo:    'Analista de Calidad',
      activo:   true,
    },
  ],

  // tabla de productos original — se mantiene para compatibilidad
  productos: [],
};

module.exports = db;
