/**
 * src/repositories/UsuarioRepository.js
 * Repositorio en memoria para usuarios.
 * Principio OCP: reemplazable por MySQLUsuarioRepository sin tocar el resto.
 * Patrón Repository: abstrae la fuente de datos.
 */
'use strict';

const Usuario = require('../models/Usuario');
const db      = require('../../config/database');

class UsuarioRepository {
  constructor() {
    this._store = db.usuarios;
  }

  /**
   * Busca un usuario por email (case-insensitive).
   * @param {string} email
   * @returns {Usuario|null}
   */
  findByEmail(email) {
    const data = this._store.find(
      u => u.email.toLowerCase() === email.toLowerCase()
    );
    return data ? Usuario.fromDB(data) : null;
  }

  /**
   * Busca un usuario por ID.
   * @param {string} id
   * @returns {Usuario|null}
   */
  findById(id) {
    const data = this._store.find(u => u.id === id);
    return data ? Usuario.fromDB(data) : null;
  }
}

module.exports = UsuarioRepository;
