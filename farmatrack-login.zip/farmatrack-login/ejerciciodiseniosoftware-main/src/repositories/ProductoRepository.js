/**
 * src/repositories/ProductoRepository.js
 * Implementación concreta del repositorio usando almacenamiento en memoria.
 * Principio: Liskov Substitution - implementa correctamente el contrato de IProductoRepository.
 * Patrón: Repository Pattern - abstrae la capa de persistencia.
 *
 * Para usar con base de datos real: crear MySQLProductoRepository, MongoProductoRepository, etc.
 * sin modificar el resto de la aplicación (Open/Closed Principle).
 */

'use strict';

const IProductoRepository = require('./IProductoRepository');
const Producto = require('../models/Producto');
const db = require('../../config/database');

class ProductoRepository extends IProductoRepository {
  constructor() {
    super();
    this._store = db.productos; // Referencia a la "tabla"
  }

  /**
   * Obtiene todos los productos
   * @returns {Promise<Producto[]>}
   */
  async findAll() {
    return this._store.map(Producto.fromDB);
  }

  /**
   * Busca un producto por ID
   * @param {string} id
   * @returns {Promise<Producto|null>}
   */
  async findById(id) {
    const data = this._store.find(p => p.id === id);
    return data ? Producto.fromDB(data) : null;
  }

  /**
   * Busca productos por categoría
   * @param {string} categoria
   * @returns {Promise<Producto[]>}
   */
  async findByCategoria(categoria) {
    return this._store
      .filter(p => p.categoria.toLowerCase() === categoria.toLowerCase())
      .map(Producto.fromDB);
  }

  /**
   * Crea un nuevo producto
   * @param {Object} data
   * @returns {Promise<Producto>}
   */
  async create(data) {
    const producto = new Producto(data);
    this._store.push(producto.toJSON());
    return producto;
  }

  /**
   * Actualiza un producto existente
   * @param {string} id
   * @param {Object} data
   * @returns {Promise<Producto|null>}
   */
  async update(id, data) {
    const index = this._store.findIndex(p => p.id === id);
    if (index === -1) return null;

    const producto = Producto.fromDB(this._store[index]);
    producto.update(data);
    this._store[index] = producto.toJSON();
    return producto;
  }

  /**
   * Elimina un producto por ID
   * @param {string} id
   * @returns {Promise<boolean>}
   */
  async delete(id) {
    const index = this._store.findIndex(p => p.id === id);
    if (index === -1) return false;
    this._store.splice(index, 1);
    return true;
  }

  /**
   * Cuenta el total de productos
   * @returns {Promise<number>}
   */
  async count() {
    return this._store.length;
  }

  /**
   * Obtiene categorías únicas
   * @returns {Promise<string[]>}
   */
  async getCategorias() {
    const categorias = [...new Set(this._store.map(p => p.categoria))];
    return categorias.filter(Boolean).sort();
  }
}

module.exports = ProductoRepository;
