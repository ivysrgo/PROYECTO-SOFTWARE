/**
 * src/validators/productoValidator.js
 * Validaciones de entrada usando express-validator.
 * Principio: Single Responsibility - solo valida datos de entrada.
 * Principio: Open/Closed - agregar nuevas reglas sin modificar el controlador.
 */

'use strict';

const { body, validationResult } = require('express-validator');

/**
 * Reglas de validación para crear un producto
 */
const reglasCrear = [
  body('nombre')
    .trim()
    .notEmpty().withMessage('El nombre es obligatorio')
    .isLength({ min: 2, max: 100 }).withMessage('El nombre debe tener entre 2 y 100 caracteres'),

  body('descripcion')
    .trim()
    .optional({ nullable: true, checkFalsy: true })
    .isLength({ max: 500 }).withMessage('La descripción no puede superar 500 caracteres'),

  body('precio')
    .notEmpty().withMessage('El precio es obligatorio')
    .isFloat({ min: 0 }).withMessage('El precio debe ser un número mayor o igual a 0'),

  body('cantidad')
    .notEmpty().withMessage('La cantidad es obligatoria')
    .isInt({ min: 0 }).withMessage('La cantidad debe ser un número entero mayor o igual a 0'),

  body('categoria')
    .trim()
    .notEmpty().withMessage('La categoría es obligatoria')
    .isLength({ min: 2, max: 50 }).withMessage('La categoría debe tener entre 2 y 50 caracteres'),
];

/**
 * Reglas de validación para actualizar (mismas reglas, todas opcionales)
 */
const reglasActualizar = [
  body('nombre')
    .optional()
    .trim()
    .notEmpty().withMessage('El nombre no puede estar vacío')
    .isLength({ min: 2, max: 100 }).withMessage('El nombre debe tener entre 2 y 100 caracteres'),

  body('descripcion')
    .optional({ nullable: true, checkFalsy: true })
    .trim()
    .isLength({ max: 500 }).withMessage('La descripción no puede superar 500 caracteres'),

  body('precio')
    .optional()
    .isFloat({ min: 0 }).withMessage('El precio debe ser un número mayor o igual a 0'),

  body('cantidad')
    .optional()
    .isInt({ min: 0 }).withMessage('La cantidad debe ser un número entero mayor o igual a 0'),

  body('categoria')
    .optional()
    .trim()
    .notEmpty().withMessage('La categoría no puede estar vacía')
    .isLength({ min: 2, max: 50 }).withMessage('La categoría debe tener entre 2 y 50 caracteres'),
];

/**
 * Middleware que procesa los errores de validación
 * @param {Function} redirectTo - Función que recibe (req, res) para redirigir con errores
 */
const manejarErrores = (redirectTo) => (req, res, next) => {
  const errores = validationResult(req);
  if (!errores.isEmpty()) {
    const mensajes = errores.array().map(e => e.msg);
    req.flash = { tipo: 'error', mensajes };
    return redirectTo(req, res);
  }
  next();
};

module.exports = { reglasCrear, reglasActualizar, manejarErrores };
