/**
 * src/services/AuthService.js
 * Lógica de negocio de autenticación.
 * Principio SRP: solo maneja las reglas de autenticación.
 * Principio DIP: depende de la abstracción UsuarioRepository.
 */
'use strict';

const AppError = require('../utils/AppError');

class AuthService {
  /**
   * @param {UsuarioRepository} usuarioRepository
   */
  constructor(usuarioRepository) {
    this._repo = usuarioRepository;
  }

  /**
   * Valida credenciales y devuelve el objeto de sesión.
   * @param {string} email
   * @param {string} password
   * @returns {{ id, nombre, email, rol, cargo }}
   */
  login(email, password) {
    // 1. Validar que vengan los campos
    if (!email || !email.trim()) {
      throw new AppError('El correo es requerido.', 400);
    }
    if (!password) {
      throw new AppError('La contraseña es requerida.', 400);
    }

    // 2. Buscar usuario
    const usuario = this._repo.findByEmail(email.trim());
    if (!usuario) {
      throw new AppError('Credenciales incorrectas.', 401);
    }

    // 3. Verificar que esté activo
    if (!usuario.activo) {
      throw new AppError('Tu cuenta está desactivada. Contacta al administrador.', 403);
    }

    // 4. Verificar contraseña
    if (!usuario.verificarPassword(password)) {
      throw new AppError('Credenciales incorrectas.', 401);
    }

    // 5. Devolver datos seguros para la sesión
    return usuario.toSession();
  }
}

module.exports = AuthService;
