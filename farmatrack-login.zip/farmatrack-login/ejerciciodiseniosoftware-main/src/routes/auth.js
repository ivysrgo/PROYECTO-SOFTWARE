/**
 * src/routes/auth.js
 * Rutas de autenticación.
 * Patrón Front Controller: delega al AuthController.
 */
'use strict';

const express              = require('express');
const router               = express.Router();
const UsuarioRepository    = require('../repositories/UsuarioRepository');
const AuthService          = require('../services/AuthService');
const AuthController       = require('../controllers/AuthController');

// ── Composition Root (DI) ──────────────────────────────────────
const usuarioRepo = new UsuarioRepository();
const authSvc     = new AuthService(usuarioRepo);
const authCtrl    = new AuthController(authSvc);

// ── Rutas ──────────────────────────────────────────────────────
router.get('/login',  authCtrl.showLogin);   // Mostrar formulario
router.post('/login', authCtrl.login);       // Procesar login
router.post('/logout', authCtrl.logout);     // Cerrar sesión

module.exports = router;
