/**
 * src/routes/productos.js
 * Definición de rutas RESTful para el recurso Producto.
 * Patrón: Front Controller delegando a controladores específicos.
 *
 * GET    /productos           → index (listar)
 * GET    /productos/nuevo     → new (formulario crear)
 * POST   /productos           → create (procesar creación)
 * GET    /productos/:id       → show (detalle)
 * GET    /productos/:id/editar → edit (formulario editar)
 * PUT    /productos/:id       → update (procesar actualización)
 * DELETE /productos/:id       → destroy (eliminar)
 */

'use strict';

const express = require('express');
const router = express.Router();

const ProductoRepository = require('../repositories/ProductoRepository');
const ProductoService = require('../services/ProductoService');
const ProductoController = require('../controllers/ProductoController');
const { reglasCrear, reglasActualizar, manejarErrores } = require('../validators/productoValidator');

// ── Inyección de dependencias (Composition Root) ──────────────────────────────
const productoRepository = new ProductoRepository();
const productoService = new ProductoService(productoRepository);
const productoController = new ProductoController(productoService);

// ── Rutas ─────────────────────────────────────────────────────────────────────

// Formulario nuevo (antes de :id para evitar conflicto)
router.get('/nuevo', productoController.new);

// Listar todos
router.get('/', productoController.index);

// Detalle
router.get('/:id', productoController.show);

// Formulario editar
router.get('/:id/editar', productoController.edit);

// Crear
router.post(
  '/',
  reglasCrear,
  manejarErrores((req, res) => {
    productoController.create(req, res, () => {});
  }),
  productoController.create
);

// Actualizar (method-override convierte POST → PUT)
router.put(
  '/:id',
  reglasActualizar,
  manejarErrores((req, res) => {
    productoController.update(req, res, () => {});
  }),
  productoController.update
);

// Eliminar (method-override convierte POST → DELETE)
router.delete('/:id', productoController.destroy);

module.exports = router;
