/**
 * src/routes/index.js
 * Router principal — monta todos los sub-routers.
 */
'use strict';

const express      = require('express');
const router       = express.Router();
const authRouter   = require('./auth');
const productosRouter = require('./productos');
const { requireAuth, injectUser } = require('../middlewares/auth');

// ── Rutas públicas ─────────────────────────────────────────────
router.use('/auth', authRouter);

// ── Raíz: redirige según sesión ────────────────────────────────
router.get('/', injectUser, (req, res) => {
  if (res.locals.currentUser) return res.redirect('/bienvenida');
  res.redirect('/auth/login');
});

// ── Página de bienvenida (requiere sesión) ─────────────────────
router.get('/bienvenida', requireAuth, (req, res) => {
  res.render('auth/bienvenida', {
    title: 'Bienvenido',
    layout: 'layouts/app',
  });
});

// ── Rutas originales de productos (mantienen compatibilidad) ───
router.use('/productos', requireAuth, productosRouter);

module.exports = router;
