/**
 * src/models/Producto.js
 * Modelo de dominio - representa la entidad Producto.
 * Principio: Single Responsibility - solo define la estructura y validación del dominio.
 */

'use strict';

const { v4: uuidv4 } = require('uuid');

class Producto {
  constructor({ id, nombre, descripcion, precio, cantidad, categoria, createdAt, updatedAt } = {}) {
    this.id = id || uuidv4();
    this.nombre = nombre || '';
    this.descripcion = descripcion || '';
    this.precio = parseFloat(precio) || 0;
    this.cantidad = parseInt(cantidad) || 0;
    this.categoria = categoria || '';
    this.createdAt = createdAt || new Date().toISOString();
    this.updatedAt = updatedAt || new Date().toISOString();
  }

  /**
   * Actualiza los campos del producto y refresca updatedAt
   */
  update({ nombre, descripcion, precio, cantidad, categoria }) {
    if (nombre !== undefined) this.nombre = nombre;
    if (descripcion !== undefined) this.descripcion = descripcion;
    if (precio !== undefined) this.precio = parseFloat(precio);
    if (cantidad !== undefined) this.cantidad = parseInt(cantidad);
    if (categoria !== undefined) this.categoria = categoria;
    this.updatedAt = new Date().toISOString();
    return this;
  }

  /**
   * Serializa el modelo a objeto plano
   */
  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      descripcion: this.descripcion,
      precio: this.precio,
      cantidad: this.cantidad,
      categoria: this.categoria,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
    };
  }

  /**
   * Factory method - crea desde datos crudos
   */
  static fromDB(data) {
    return new Producto(data);
  }
}

module.exports = Producto;
