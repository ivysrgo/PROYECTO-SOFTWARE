/**
 * src/controllers/AuthController.js
 * Controlador MVC para autenticación.
 * Principio SRP: solo maneja el flujo HTTP de login/logout.
 * Principio DIP: recibe AuthService inyectado.
 */
'use strict';

const AppError = require('../utils/AppError');

class AuthController {
  /**
   * @param {AuthService} authService
   */
  constructor(authService) {
    this._svc = authService;

    // Bind para que `this` funcione en callbacks de Express
    this.showLogin   = this.showLogin.bind(this);
    this.login       = this.login.bind(this);
    this.logout      = this.logout.bind(this);
  }

  // ─────────────────────────────────────────
  // GET /auth/login
  // Muestra el formulario de login.
  // Si ya hay sesión activa, redirige al home.
  // ─────────────────────────────────────────
  showLogin(req, res) {
    if (req.session && req.session.usuario) {
      return res.redirect('/');
    }

    res.render('auth/login', {
      layout:  'layouts/auth',
      title:   'Iniciar sesión',
      error:   req.flash('error'),
      email:   req.flash('email'),
    });
  }

  // ─────────────────────────────────────────
  // POST /auth/login
  // Procesa el formulario, crea sesión.
  // ─────────────────────────────────────────
  login(req, res) {
    const { email, password } = req.body;

    try {
      const usuarioSesion = this._svc.login(email, password);

      // Guardar en sesión
      req.session.usuario = usuarioSesion;

      // Regenerar ID de sesión por seguridad (previene session fixation)
      req.session.regenerate((err) => {
        if (err) {
          req.session.usuario = usuarioSesion;
        }
        req.session.usuario = usuarioSesion;
        res.redirect('/bienvenida');
      });

    } catch (err) {
      // Guardar email para re-llenarlo en el form
      req.flash('error', err.message);
      req.flash('email', email || '');
      res.redirect('/auth/login');
    }
  }

  // ─────────────────────────────────────────
  // POST /auth/logout
  // Destruye la sesión y redirige al login.
  // ─────────────────────────────────────────
  logout(req, res) {
    req.session.destroy(() => {
      res.redirect('/auth/login');
    });
  }
}

module.exports = AuthController;
