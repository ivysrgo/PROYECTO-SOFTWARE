/**
 * src/controllers/ProductoController.js
 * Controlador MVC - orquesta peticiones HTTP y respuestas de vistas.
 * Principio: Single Responsibility - solo maneja el flujo HTTP.
 * Principio: Dependency Inversion - recibe el servicio inyectado.
 * Patrón: MVC Controller.
 */

'use strict';

const AppError = require('../utils/AppError');

class ProductoController {
  /**
   * @param {ProductoService} productoService - Inyección de dependencia
   */
  constructor(productoService) {
    this._service = productoService;

    // Bindear métodos para que `this` funcione en los callbacks de Express
    this.index = this.index.bind(this);
    this.show = this.show.bind(this);
    this.new = this.new.bind(this);
    this.create = this.create.bind(this);
    this.edit = this.edit.bind(this);
    this.update = this.update.bind(this);
    this.destroy = this.destroy.bind(this);
  }

  // ─────────────────────────────────────────
  // GET /productos
  // ─────────────────────────────────────────
  async index(req, res, next) {
    try {
      const { productos, stats } = await this._service.obtenerTodos();
      const categorias = await this._service.obtenerCategorias();

      res.render('productos/index', {
        title: 'Gestión de Productos',
        productos,
        stats,
        categorias,
        flash: req.flash || null,
      });
    } catch (err) {
      next(err);
    }
  }

  // ─────────────────────────────────────────
  // GET /productos/:id
  // ─────────────────────────────────────────
  async show(req, res, next) {
    try {
      const producto = await this._service.obtenerPorId(req.params.id);
      res.render('productos/show', {
        title: producto.nombre,
        producto,
      });
    } catch (err) {
      next(err);
    }
  }

  // ─────────────────────────────────────────
  // GET /productos/nuevo
  // ─────────────────────────────────────────
  async new(req, res, next) {
    try {
      const categorias = await this._service.obtenerCategorias();
      res.render('productos/new', {
        title: 'Nuevo Producto',
        categorias,
        producto: {},
        errores: [],
        flash: req.flash || null,
      });
    } catch (err) {
      next(err);
    }
  }

  // ─────────────────────────────────────────
  // POST /productos
  // ─────────────────────────────────────────
  async create(req, res, next) {
    try {
      // Si hay flash de validación, re-renderizar formulario
      if (req.flash && req.flash.tipo === 'error') {
        const categorias = await this._service.obtenerCategorias();
        return res.status(422).render('productos/new', {
          title: 'Nuevo Producto',
          categorias,
          producto: req.body,
          errores: req.flash.mensajes,
          flash: req.flash,
        });
      }

      await this._service.crear(req.body);
      res.redirect('/productos?flash=creado');
    } catch (err) {
      if (err instanceof AppError) {
        const categorias = await this._service.obtenerCategorias();
        return res.status(err.statusCode).render('productos/new', {
          title: 'Nuevo Producto',
          categorias,
          producto: req.body,
          errores: [err.message],
          flash: { tipo: 'error', mensajes: [err.message] },
        });
      }
      next(err);
    }
  }

  // ─────────────────────────────────────────
  // GET /productos/:id/editar
  // ─────────────────────────────────────────
  async edit(req, res, next) {
    try {
      const [producto, categorias] = await Promise.all([
        this._service.obtenerPorId(req.params.id),
        this._service.obtenerCategorias(),
      ]);

      res.render('productos/edit', {
        title: `Editar: ${producto.nombre}`,
        producto,
        categorias,
        errores: [],
        flash: req.flash || null,
      });
    } catch (err) {
      next(err);
    }
  }

  // ─────────────────────────────────────────
  // PUT /productos/:id
  // ─────────────────────────────────────────
  async update(req, res, next) {
    try {
      if (req.flash && req.flash.tipo === 'error') {
        const [producto, categorias] = await Promise.all([
          this._service.obtenerPorId(req.params.id),
          this._service.obtenerCategorias(),
        ]);
        return res.status(422).render('productos/edit', {
          title: `Editar: ${producto.nombre}`,
          producto: { ...producto, ...req.body },
          categorias,
          errores: req.flash.mensajes,
          flash: req.flash,
        });
      }

      await this._service.actualizar(req.params.id, req.body);
      res.redirect('/productos?flash=actualizado');
    } catch (err) {
      if (err instanceof AppError) {
        const categorias = await this._service.obtenerCategorias();
        return res.status(err.statusCode).render('productos/edit', {
          title: 'Editar Producto',
          producto: { id: req.params.id, ...req.body },
          categorias,
          errores: [err.message],
          flash: { tipo: 'error', mensajes: [err.message] },
        });
      }
      next(err);
    }
  }

  // ─────────────────────────────────────────
  // DELETE /productos/:id
  // ─────────────────────────────────────────
  async destroy(req, res, next) {
    try {
      await this._service.eliminar(req.params.id);
      res.redirect('/productos?flash=eliminado');
    } catch (err) {
      next(err);
    }
  }
}

module.exports = ProductoController;
