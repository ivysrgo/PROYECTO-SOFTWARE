/**
 * src/middlewares/flashMessages.js
 * Middleware para mensajes flash via query params (sin sesiones).
 * Principio: Single Responsibility.
 */

'use strict';

const MENSAJES = {
  creado: { tipo: 'success', texto: '✅ Producto creado exitosamente.' },
  actualizado: { tipo: 'success', texto: '✅ Producto actualizado exitosamente.' },
  eliminado: { tipo: 'warning', texto: '🗑️ Producto eliminado exitosamente.' },
};

const flashMessages = (req, res, next) => {
  const flashKey = req.query.flash;
  res.locals.flash = MENSAJES[flashKey] || null;
  next();
};

module.exports = flashMessages;
